#!/system/bin/sh
  ppr=/sys/module/process_reclaim/parameters
        set_value 90 $ppr/pressure_max
        set_value 70 $ppr/pressure_min
        set_value 512 $ppr/per_swap_size
        set_value 1 $ppr/enable_process_reclaim
