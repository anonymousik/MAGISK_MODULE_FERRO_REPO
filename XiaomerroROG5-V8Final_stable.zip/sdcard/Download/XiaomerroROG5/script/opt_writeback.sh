check(){
TIMEs=0
until [ "$TIMEs" == 15 ]
do
APP=`dumpsys activity lru | grep 'TOP'|awk 'NR==1'|awk -F '[ :/]+' '{print $7}'`
      if [ "$APP" != "$apps" ]; then
      let 'TIMEs+=1'
      apps="$APP"
      fi
      sleep 3
done
}
wrote(){
	echo "Uruchomione ${TIMES} razy"
	echo "" `data "+%Y-%m-%d %H:%M:%S"`
	echo "Trwa wywoływanie zapisu zwrotnego..."
	    writeback "huge"
	DATA=$(cat /sys/block/zram0/bd_stat)
	READ=$(echo ${DATA} | awk '{print $2}')
	WRITE=$(echo ${DATA} | awk '{print $3}')
	let READ=${READ}*4/1024
	let WRITE=${WRITE}*4/1024
	echo "ODCZYT：${READ}MB  ZAPIS：${WRITE}MB"
	echo "--------------------------------------------"
}
writeback(){
		let 'TIMES+=1'
		echo ${1} > /sys/block/zram0/writeback
		sleep 30
}
BootOptimization(){
      echo "optymalizacja rozruchu..."
      sleep 3m
      echo all > /sys/block/zram0/idle
      sleep 2m
      writeback "idle"
      echo "" `date "+%Y-%m-%d %H:%M:%S"`
      echo "Powodzenie!！"
      echo "--------------------------------------------"
}
    echo "Moduł ładuje się normalnie"
    BootOptimization
	while [ true ]; do
	  check
	  wrote
     sleep 15
done

