#Technical Mundeer /system/bin/sh
MODDIR=${0%/*}
write /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor performance
write /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 0
write /sys/devices/system/cpu/cpufreq/performance/boost 1
write /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 99
write /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 1
write /sys/devices/system/cpu/cpufreq/performance/align_windows 1
write /sys/module/adreno_idler/parameters/adreno_idler_active 0
write /sys/module/lazyplug/parameters/nr_possible_cores 8
write /sys/module/msm_performance/parameters/touchboost 1
write /dev/cpuset/foreground/boost/cpus 6-8
write /dev/cpuset/foreground/cpus 0-5,6-8
write /dev/cpuset/top-app/cpus 0-8


dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
sleep 1
done
ln -s /sbin/.magisk/busybox/*
sleep 20
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo "85 1747200:90 1843200:95" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/target_loads
echo "85 2150400:90 2208000:95" > /sys/devices/system/cpu/cpufreq/policy5/schedutil/target_loads
echo "15000 1401600:35000" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/above_hispeed_delay
echo "9000" > /sys/devices/system/cpu/cpufreq/policy5/interactive/above_hispeed_delay
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/interactive/max_freq_hysteresis
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy5/scaling_governor
echo "95" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_load
echo "95" > /sys/devices/system/cpu/cpufreq/policy0/interactive/hispeed_load
echo "95" > /sys/devices/system/cpu/cpufreq/policy5/schedutil/hispeed_load
echo "95" > /sys/devices/system/cpu/cpufreq/policy5/interactive/hispeed_load
echo "95" > /sys/devices/system/cpu/cpufreq/policy0/interactive/go_hispeed_load
echo "95" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/go_hispeed_load
echo '95' > /sys/devices/system/cpu/cpufreq/policy5/interactive/go_hispeed_load
echo '95' > /sys/devices/system/cpu/cpufreq/policy5/schedutil/go_hispeed_load
echo "N" > /sys/module/msm_thermal/parameters/enabled
echo "0" > /sys/module/msm_thermal/core_control/cpus_offlined
echo "1" > /sys/module/msm_thermal/core_control/enabled
echo "1" > /sys/module/msm_performance/parameters/touchboost;
echo "0" > /sys/devices/system/cpu/cpufreq/interactive/above_hispeed_delay;
echo "1" > /sys/devices/system/cpu/cpufreq/policy0/interactive/boost
echo "1" > /sys/devices/system/cpu/cpufreq/policy0/schedutil/boost
echo "1" > /sys/devices/system/cpu/cpufreq/policy6/interactive/boost
echo "1" > /sys/devices/system/cpu/cpufreq/policy6/schedutil/boost
echo "1" > /sys/devices/system/cpu/cpufreq/interactive/boost;
echo "1" > /sys/devices/system/cpu/cpufreq/interactive/align_windows
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/boost
echo "1" > /sys/devices/system/cpu/cpufreq/schedutil/align_windows
echo "2" > /sys/class/devfreq/6000000.qcom,kgsl-3d0/adrenoboost
echo 'msm-adreno-tz' > /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor;
echo 'msm-adreno-tz' > /sys/kernel/gpu/gpu_governor;
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "2" > /sys/class/devfreq/6900000.qcom,kgsl-3d0/subsystem/5900000.qcom,kgsl-3d0/adrenoboost
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores
echo "0-7" > /dev/cpuset/foreground/cpus;
echo "0-7" > /dev/cpuset/foreground/boost/cpus;
echo "0-7" > /dev/cpuset/top-app/cpus;
echo "0-7" > /dev/cpuset/audio-app/cpus;
echo "0-7" > /dev/cpuset/background/cpus;
echo "0-7" > /dev/cpuset/camera-daemon/cpus;
echo "0-7" > /dev/cpuset/rt/cpus;
echo '10' > /dev/stune/foreground/schedtune.boost;
echo '12' > /dev/stune/top-app/schedtune.boost;
echo '8' > /dev/stune/schedtune.boost;
echo '1' > /dev/stune/foreground/schedtune.sched_boost_no_override;
echo '1' > /dev/stune/top-app/schedtune.sched_boost_no_override;
echo '0' > /dev/stune/schedtune.colocate;
echo '0' > /dev/stune/background/schedtune.colocate;
echo '0' > /dev/stune/system-background/schedtune.colocate;
echo '0' > /dev/stune/foreground/schedtune.colocate;
echo '1' > /dev/stune/top-app/schedtune.colocate;
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy6/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/interactive/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy6/interactive/iowait_boost_enable;
echo '100' > /sys/module/cpu_boost/parameters/topkek_boost_ms
echo '100' > /sys/module/cpu_boost/parameters/input_boost_ms
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/interactive/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy6/schedutil/pl
echo '1' > /sys/devices/system/cpu/cpufreq/policy6/interactive/pl
echo '1536000' > /sys/devices/system/cpu/cpufreq/policy0/scaling_cur_freq
echo '1536000' > /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_cur_freq
echo '1843200' > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy5/scaling_cur_freq
echo '1958400' > /sys/devices/system/cpu/cpufreq/policy5/cpuinfo_cur_freq
echo '2208000' > /sys/devices/system/cpu/cpufreq/policy5/scaling_max_freq
echo '1113000' > /sys/devices/system/cpu/cpufreq/policy6/cpuinfo_min_freq
echo '1536000' > /sys/devices/system/cpu/cpufreq/policy0/interactive/hispeed_freq
echo '1536000' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/hispeed_freq
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy6/interactive/hispeed_freq
echo '1747200' > /sys/devices/system/cpu/cpufreq/policy6/schedutil/hispeed_freq
echo "0 0 0 0" > /proc/sys/kernel/printk
echo "0" > /proc/sys/kernel/compat-log
echo "0" > /proc/sys/kernel/panic
echo "0" > /proc/sys/kernel/panic_on_oops
echo "0" > /proc/sys/kernel/softlockup_panic
echo "0" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "0" > /proc/sys/kernel/nmi_watchdog
echo "5" > /proc/sys/kernel/sched_walt_init_task_load_pct
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo '30' >  /sys/module/cpu_boost/parameters/input_boost_ms
echo '0:1401600 1:1401600 2:1401600 3:1401600 4:1747200 5:1747200 6:1747200 7:1747200' >  /sys/module/cpu_boost/parameters/input_boost_freq
echo 'Y' > /sys/module/cpu_boost/parameters/sched_boost_on_input
echo '30' > /sys/module/cpu_input_boost/parameters/input_boost_duration
echo '1612800' > /sys/module/cpu_input_boost/parameters/input_boost_freq_hp
echo '1747200' > /sys/module/cpu_input_boost/parameters/input_boost_freq_lp
echo '90' > /proc/sys/net/ipv4/neigh/wlan1/anycast_delay
echo '70' > /proc/sys/net/ipv4/neigh/wlan1/proxy_delay
echo '90' > /proc/sys/net/ipv4/neigh/wlan0/anycast_delay
echo '70' > /proc/sys/net/ipv4/neigh/wlan0/proxy_delay
if [ -e /proc/sys/net/ipv4/tcp_max_orphans ]; then
echo "400000" > /proc/sys/net/ipv4/tcp_max_orphans
fi
if [ -e /proc/sys/net/netfilter/nf_conntrack_max ]; then
echo "1000000" > /proc/sys/net/netfilter/nf_conntrack_max
fi
if [ -e /proc/sys/fs/file-max ]; then
echo "10000000" > /proc/sys/fs/file-max
fi
if [ -e /sys/module/nf_conntrack/parameters/hashsize ]; then
echo "250000" > /sys/module/nf_conntrack/parameters/hashsize
fi
if [ -e /proc/sys/net/core/rmem_max ]; then
echo "8738000" > /proc/sys/net/core/rmem_max
fi
if [ -e /proc/sys/net/core/wmem_max ]; then
echo "6553600" > /proc/sys/net/core/wmem_max
fi
if [ -e /proc/sys/net/ipv4/tcp_rmem ]; then
echo "8192,873800,8738000" > /proc/sys/net/ipv4/tcp_rmem
fi
if [ -e /proc/sys/net/ipv4/tcp_wmem ]; then
echo "4096,655360,6553600" > /proc/sys/net/ipv4/tcp_wmem
fi
if [ -e /proc/sys/net/ipv4/tcp_max_tw_buckets ]; then
echo "360000" > /proc/sys/net/ipv4/tcp_max_tw_buckets
fi
if [ -e /proc/sys/net/core/netdev_max_backlog ]; then
echo "30000" > /proc/sys/net/core/netdev_max_backlog
fi
if [ -e /proc/sys/net/ipv4/tcp_max_syn_backlog ]; then
echo "16384"  > /proc/sys/net/ipv4/tcp_max_syn_backlog
fi
if [ -e /proc/sys/net/ipv4/ip_local_port_range ]; then
echo "30000,65535" > /proc/sys/net/ipv4/ip_local_port_range
fi
if [ -e /proc/sys/net/ipv4/tcp_synack_retries ]; then
echo "1" > /proc/sys/net/ipv4/tcp_synack_retries
fi
if [ -e /proc/sys/net/ipv4/tcp_timestamps ]; then
echo '0' > /proc/sys/net/ipv4/tcp_timestamps
fi
if [ -e /proc/sys/net/ipv4/tcp_sack ]; then
echo '0' > /proc/sys/net/ipv4/tcp_sack
fi
if [ -e /proc/sys/net/ipv4/tcp_window_scaling ]; then
echo "1" > /proc/sys/net/ipv4/tcp_window_scaling
fi
if [ -e /proc/sys/net/ipv4/tcp_no_metrics_save ]; then
echo "1" > /proc/sys/net/ipv4/tcp_no_metrics_save
fi
if [ -e /proc/sys/net/ipv4/tcp_sack ]; then
echo "1" > /proc/sys/net/ipv4/tcp_sack
fi
if [ -e /proc/sys/net/ipv4/tcp_congestion_control ]; then
echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control
fi
if [ -e /proc/sys/net/ipv4/tcp_fin_timeout ]; then
echo "5" > /proc/sys/net/ipv4/tcp_fin_timeout
fi
if [ -e /proc/sys/net/ipv4/tcp_keepalive_intvl ]; then
echo "30" > /proc/sys/net/ipv4/tcp_keepalive_intvl
fi
if [ -e /proc/sys/net/ipv4/tcp_keepalive_probes ]; then
echo "5" > /proc/sys/net/ipv4/tcp_keepalive_probes
fi
if [ -e /proc/sys/net/ipv4/tcp_tw_recycle ]; then
echo "1" > /proc/sys/net/ipv4/tcp_tw_recycle
fi
if [ -e /proc/sys/net/ipv4/tcp_tw_reuse ]; then
echo "1" > /proc/sys/net/ipv4/tcp_tw_reuse
fi
if [ -e /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_fin_wait ]; then
echo "1" > /proc/sys/net/netfilter/nf_conntrack_tcp_timeout_fin_wait
fi
echo 'noop' > /sys/block/mmcblk0/queue/scheduler
echo 'noop' > /sys/block/mmcblk1/queue/scheduler
echo '256' > /sys/block/mmcblk0/queue/nr_requests
echo '512' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '256' > /sys/block/mmcblk1/queue/nr_requests
echo '512' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '256' > /sys/block/dm-0/queue/nr_requests
echo '1024' > /sys/block/dm-0/queue/read_ahead_kb
echo 'noop' > /sys/block/sda/queue/scheduler
echo '512' > /sys/block/sda/queue/read_ahead_kb
echo '0' > /sys/block/sda/queue/rotational
echo '0' > /sys/block/sda/queue/iostats
echo '0' > /sys/block/sda/queue/add_random
echo '1' > /sys/block/sda/queue/rq_affinity
echo '0' > /sys/block/sda/queue/nomerges
echo '256' > /sys/block/sda/queue/nr_requests
echo 'noop' > /sys/block/sdb/queue/scheduler
echo '512' > /sys/block/sdb/queue/read_ahead_kb
echo '0' > /sys/block/sdb/queue/rotational
echo '0' > /sys/block/sdb/queue/iostats
echo '0' > /sys/block/sdb/queue/add_random
echo '1' > /sys/block/sdb/queue/rq_affinity
echo '0' > /sys/block/sdb/queue/nomerges
echo '256' > /sys/block/sdb/queue/nr_requests
echo 'noop' > /sys/block/sdc/queue/scheduler
echo '512' > /sys/block/sdc/queue/read_ahead_kb
echo '0' > /sys/block/sdc/queue/rotational
echo '0' > /sys/block/sdc/queue/iostats
echo '0' > /sys/block/sdc/queue/add_random
echo '1' > /sys/block/sdc/queue/rq_affinity
echo '0' > /sys/block/sdc/queue/nomerges
echo '256' > /sys/block/sdc/queue/nr_requests
echo 'noop' > /sys/block/sdd/queue/scheduler
echo '512' > /sys/block/sdd/queue/read_ahead_kb
echo '0' > /sys/block/sdd/queue/rotational
echo '0' > /sys/block/sdd/queue/iostats
echo '0' > /sys/block/sdd/queue/add_random
echo '1' > /sys/block/sdd/queue/rq_affinity
echo '0' > /sys/block/sdd/queue/nomerges
echo '256' > /sys/block/sdd/queue/nr_requests
echo 'noop' > /sys/block/sde/queue/scheduler
echo '512' > /sys/block/sde/queue/read_ahead_kb
echo '0' > /sys/block/sde/queue/rotational
echo '0' > /sys/block/sde/queue/iostats
echo '0' > /sys/block/sde/queue/add_random
echo '1' > /sys/block/sde/queue/rq_affinity
echo '0' > /sys/block/sde/queue/nomerges
echo '256' > /sys/block/sde/queue/nr_requests
echo 'noop' > /sys/block/sdf/queue/scheduler
echo '512' > /sys/block/sdf/queue/read_ahead_kb
echo '0' > /sys/block/sdf/queue/rotational
echo '0' > /sys/block/sdf/queue/iostats
echo '0' > /sys/block/sdf/queue/add_random
echo '1' > /sys/block/sdf/queue/rq_affinity
echo '0' > /sys/block/sdf/queue/nomerges
echo '256' > /sys/block/sdf/queue/nr_requests
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' > /sys/kernel/dyn_fsync/Dyn_fsync_active
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.bootstrap.service.NearbyBootstrapService"
su -c "pm disable com.google.android.gms/NearbyMessagesService"
su -c "pm disable com.google.android.gms/com.google.android.gms.nearby.connection.service.NearbyConnectionsAndroidService"
su -c "pm disable com.google.android.gms/com.google.location.nearby.direct.service.NearbyDirectService"
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'
fstrim /cache
fstrim /system
fstrim /data
stop perfd;
echo '0' > /proc/sys/vm/panic_on_oom;
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '0' > /sys/block/mmcblk0/queue/rotational
echo '1' > /sys/block/mmcblk0/queue/rq_affinity
echo '0' > /sys/block/mmcblk0/queue/nomerges
;

sleep 1
done
exit 0
