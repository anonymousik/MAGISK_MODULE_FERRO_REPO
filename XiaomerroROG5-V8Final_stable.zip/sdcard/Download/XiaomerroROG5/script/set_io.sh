loop=$(cat /sys/block/zram0/backing_dev | grep -o "loop[0-9]*")
echo none > /sys/block/$loop/queue/scheduler
echo deadline > /sys/block/zram0/queue/scheduler
echo noop > /sys/block/sda/queue/scheduler
echo noop > /sys/block/sdc/queue/scheduler
echo noop > /sys/block/sdb/queue/scheduler
echo 128 > /sys/block/sda/queue/read_ahead_kb
echo 128 > /sys/block/sde/queue/read_ahead_kb
echo 1536 > /sys/block/mmcblk0/queue/read_ahead_kb
echo 2048 > /sys/block/zram0/queue/read_ahead_kb
echo 3 > /proc/sys/vm/drop_caches
echo 0 > /sys/block/zram0/queue/rotational
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
echo 11 > /proc/sys/kernel/mi_iolimit

