#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
write /proc/sys/vm/page-cluster 0
write /sys/block/zram0/max_comp_streams 16

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

# Set zram configurations
setprop ro.vendor.qti.config.zram true
#!/system/bin/sh
MODULE=/data/adb/modules
# Conflict module remover
for REMOVE in $MODULE/*Game_Unlock*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*Pubg_extrem*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*pixel*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*Pixel*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*PIXEL*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*spoof*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*SPOOF*; do
    touch $REMOVE/remove;
done;
for REMOVE in $MODULE/*Spoof*; do
    touch $REMOVE/remove;
done
