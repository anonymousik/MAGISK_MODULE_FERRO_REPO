SKIPMOUNT=true
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
REPLACE=" 
/system/lib/egl/egl.cfg
/system/lib/GL-Extensions
/product/media/audio/ringtones/*
/product/media/audio/notifications/*
/product/media/audio/ui/*
/system/app/fkm
/system/lib/egl/egl.cfg
/system/lib/RogPhone-Extensions
/product/media/audio
"
print_modname() {
  ui_print "  💣 XiaomerroROG5💣  "
  sleep 3
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *       NIECHAJ MOC BĘDZIE Z TOBĄ !     *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  sleep 3
  ui_print " *************************************************************************"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"  
  ui_print " *   (⁠☞⁠ ͡⁠°⁠ ͜⁠ʖ⁠ ͡⁠°⁠)⁠☞    *"
  ui_print " *   ミ⁠●⁠﹏⁠☉⁠ミ                    *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *************************************************************************"
  sleep 3
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *         (⁠ノ⁠｀⁠Д⁠´⁠)⁠ノ⁠彡⁠┻⁠━⁠┻   Poprawka opóźnienia żyroskopu ✔              *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  sleep 5
  ui_print " ┻⁠━⁠┻⁠ミ⁠＼⁠(⁠≧⁠ﾛ⁠≦⁠＼⁠)*********************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *     (⁠ノ⁠｀⁠Д⁠´⁠)⁠ノ⁠彡⁠┻⁠━⁠┻  Desynchronizacja gier całkowicie naprawiona ✔          *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  sleep 5
  ui_print " ************┻⁠┻⁠︵⁠¯⁠\⁠(⁠ツ⁠)⁠/⁠¯⁠︵⁠┻⁠┻ "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *           ✔  Szybkie ladowanie ✔                     *"
  ui_print " *        bez spadku wydajności w grach            *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print " 🍅┻⁠━⁠┻⁠ ⁠ヘ⁠╰⁠(⁠ ⁠•̀⁠ε⁠•́⁠ ⁠╰⁠) "
  ui_print "JESZCZE TROCHE KUFA FA "
  sleep 5
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *       ✔ Twój telefon będzie teraz NAKURWIAL!✔         *"
  ui_print " *               🌶 (⁠┛⁠◉⁠Д⁠◉⁠)⁠┛⁠彡⁠┻⁠━⁠┻JEEB JEB JEB 🌶 *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print " "
  ui_print "          ┗⁠(⁠•⁠ˇ⁠_⁠ˇ⁠•⁠)⁠―⁠→  Zakończono flashowanie modułu w 50%"
  ui_print " "
  sleep 3
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *  ✔Aktywny XiaomerRoG5 ̇5̇ 90 FPS🗝️ →⁠(⁠°⁠ ⁠۝ ⁠°⁠)⁠┗ ✔ *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print "(⁠☞⁠ ͡⁠°⁠ ͜⁠ʖ⁠ ͡⁠°⁠)⁠☞......"
  sleep 10
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *   ✔Aktywuj swoją częstotliwość odświeżania 72 Hz 90 Hz 120 Hz.       "
  ui_print "  145 Hz 165 Hz 240 Hz 🗝️ odblokowane we wszystkich grach ✔   *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print "Proszę czekać .........."
  sleep 10
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *      💣*ZASTOSOWALEM XiaomerRoG5 GPU TWEAKI✔ *"
  ui_print " *             ZA CHWILE TWOJ TELEFON ZMIENI SIE W ASUS ROGA!                       *"
  ui_print " *                                    JAK JEBANY TRANSFORM3RS!                *"
  ui_print " *                                                    *"
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  sleep 3
  ui_print " "
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *       💣*Aktywny XiaomerRoG5 ̇5̇ CPU/GPU*✔ *"
  ui_print " *                  Nowy procesor graficzny                    *"
  ui_print " *           Wartość Przeciążenie częstotliwości 🔥            *"
ui_print " *           Konfiguracja kernela, blokada reklam🔥            *"
  ui_print " *                                                    *"
  ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  sleep 3
  ui_print " "
  ui_print " "
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *     💣*(⁠ノ⁠｀⁠Д⁠´⁠)⁠ノ⁠彡⁠┻⁠━⁠┻ TWEAKI WYDAJNOSCIOWE XiaomerRoG5 ZASTOSOWANO✔    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print " "
    ui_print " *(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ(⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *   💣(⁠┛⁠◉⁠Д⁠◉⁠)⁠┛⁠彡⁠┻⁠━⁠┻*TWEAK DOTYKU XiaomerRoG5 ZASTOSOWANO  *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  ui_print " "
  ui_print "  👇  "
  ui_print "    By:  🇵🇱NieznanyNikomu "
}
on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Aktywowano GPU Boost!"
  unzip -o "$ZIPFILE" 'common/functions.sh' -d $MODPATH
 >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
. $MODPATH/common/functions.sh
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
set_permissions() {
  # The following is the default rule, DO NOT remove
         set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
         set_perm $MODPATH/system/lib/egl/egl.cfg 0 0 0644
         set_perm_recursive $MODPATH/system/etc 0 0 0755 0644
         set_perm_recursive $MODPATH/system/vendor/etc/thermal-engine-normal.conf 0 0 0755 0644
         set_perm_recursive $MODPATH/system/lib/RogPhone-Extensions 0 0 0755 0644
        set_perm_recursive $MODPATH/product/media/audio/ringtones 0 0 0755 0644
        set_perm_recursive $MODPATH/product/media/audio/notifications 0 0 0755 0644
        set_perm_recursive $MODPATH/product/media/audio/ui 0 0 0755 0644
        set_perm_recursive $MODPATH/scripts 0 0 0755 0755
}
print_modname() {
  ui_print "  💣 XiaomerroROG5 💣/ INSTALACJA.."
  sleep 3
  ui_print " (⁠╬⁠☉⁠д⁠⊙⁠)⁠⊰⁠⊹ฺ Beeeeczyyyy??  "
  sleep 3
  ui_print " Łutututututu ミ⁠●⁠﹏⁠☉⁠ミ "
  sleep 3
  ui_print " By: 🇵🇱NIEZNANYnikonu🇵🇱 "
}
on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'common/functions.sh' -d $MODPATH
 >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
. $MODPATH/common/functions.sh
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
 set_permissions() {
         set_perm_recursive $MODPATH 0 0 0755 0644
         set_perm $MODPATH/system/lib/egl/egl.cfg 0 0 0644
         set_perm_recursive $MODPATH/system/etc 0 0 0755 0644
         set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
         set_perm_recursive $MODPATH/common/system/bin 0 0 0755 0755
         set_perm_recursive $MODPATH/system/vendor/etc/thermal-engine-normal.conf 0 0 0755 0644
         set_perm_recursive $MODPATH/product/media/audio 0 0 0755 0644
         set_perm_recursive $MODPATH/common/system/lib/RogPhone-Extensions 0 0 0755 0644
}

