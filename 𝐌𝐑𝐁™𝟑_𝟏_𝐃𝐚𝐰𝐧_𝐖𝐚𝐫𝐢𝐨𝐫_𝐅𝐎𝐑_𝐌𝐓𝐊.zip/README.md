*************Merbangi Esport 🏆*************
*********𝐌𝐑𝐁™𝟑.𝟏 - 𝐃𝐚𝐰𝐧 𝐖𝐚𝐫𝐢𝐨𝐫************
******************UPDATE*********************

PERFORMANCE AND STABILITY IMPROVEMENT
NEW SET CPU CLOCK SPEEF
INTERNET SPEED BOOSTER FIX

...............TESTING DEVICE...............



CATATAN: Jika Anda menggunakan MIUI ROM harap nonaktifkan pengoptimalan MIUI dan pengoptimalan memori MIUI karena ini akan menyetel ulang sebagian besar pengaturan ini. Jika Anda menggunakan aplikasi apa pun yang mengubah pengaturan di atas, harap hapus instalan atau setidaknya nonaktifkan untuk menjalankan dan merusak pengaturan modul.
