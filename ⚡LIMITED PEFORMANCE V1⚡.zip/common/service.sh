#!/system/bin/sh

sleep 60
$MODDIR/fpsbooster 2>/dev/null

# Disable collective Device administrators;
pm disable com.google.android.gms/com.google.android.gms.mdm.receivers.MdmDeviceAdminReceiver

# Doze setup services;
su -c "pm enable com.google.android.gms/.ads.AdRequestBrokerService"
su -c "pm enable com.google.android.gms/.ads.identifier.service.AdvertisingIdService"
su -c "pm enable com.google.android.gms/.ads.social.GcmSchedulerWakeupService"
su -c "pm enable com.google.android.gms/.analytics.AnalyticsService"
su -c "pm enable com.google.android.gms/.analytics.service.PlayLogMonitorIntervalService"
su -c "pm enable com.google.android.gms/.backup.BackupTransportService"
su -c "pm enable com.google.android.gms/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$ActiveReceiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$Receiver"
su -c "pm enable com.google.android.gms/.update.SystemUpdateService\$SecretCodeReceiver"
su -c "pm enable com.google.android.gms/.thunderbird.settings.ThunderbirdSettingInjectorService"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService\$Receiver"
su -c "pm enable com.google.android.gsf/.update.SystemUpdateService\$SecretCodeReceiver"

echo 8148M >/sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon  /dev/block/zram0

chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "Interactive" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor 
echo "90" > /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 
echo "0" > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/boost 
echo "1" > /sys/module/msm_performance/parameters/touchboost 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/align_windows 
echo "performance" > /sys/devices/soc/1c00000.qcom,kgsl-3d0/devfreq/1c00000.qcom,kgsl-3d0/governor 
echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor 
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active 
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores 
echo "0-7" > /dev/cpuset/foreground/cpus 
echo "0-7" > /dev/cpuset/foreground/boost/cpus 
echo "0-7" > /dev/cpuset/top-app/cpus 
echo "0-7" > /dev/cpuset/audio-app/cpus 
echo "0-7" > /dev/cpuset/background/cpus 
echo "0-7" > /dev/cpuset/camera-daemon/cpus 
echo "0-7" > /dev/cpuset/rt/cpus 
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo "1" > /dev/stune/top-app/schedtune.colocate
echo "1" > /dev/stune/top-app/schedtune.sched_boost_enabled
echo "1" > /dev/stune/top-app/schedtune.sched_boost_no_override
echo "0" > /dev/stune/top-app/schedtune.prefer_idle
echo "0" > /dev/stune/top-app/schedtune.boost
echo "0" > /dev/stune/foreground/schedtune.colocate
echo "1" > /dev/stune/foreground/schedtune.sched_boost_enabled
echo "0" > /dev/stune/foreground/schedtune.sched_boost_no_override
echo "0" > /dev/stune/foreground/schedtune.prefer_idle
echo "0" > /dev/stune/foreground/schedtune.boost
echo "0" > /dev/stune/background/schedtune.colocate
echo "1" > /dev/stune/background/schedtune.sched_boost_enabled
echo "0" > /dev/stune/background/schedtune.sched_boost_no_override
echo "0" > /dev/stune/background/schedtune.prefer_idle
echo "0" > /dev/stune/background/schedtune.boost
echo "0" > /dev/stune/schedtune.colocate
echo "1" > /dev/stune/schedtune.sched_boost_enabled
echo "0" > /dev/stune/schedtune.sched_boost_no_override
echo "0" > /dev/stune/schedtune.prefer_idle
echo "0" > /dev/stune/schedtune.boost
echo "0" >  /sys/devices/system/cpu/cpu0/sched_mostly_idle_freq
echo "0" >  /sys/devices/system/cpu/cpu4/sched_mostly_idle_freq
echo "0" >  /sys/devices/system/cpu/cpu2/sched_mostly_idle_freq
echo "0" >  /sys/devices/system/cpu/cpu4/sched_mostly_idle_freq
echo "0" >  /sys/devices/system/cpu/cpu6/sched_mostly_idle_freq
echo "0" >  /sys/devices/system/cpu/cpu1/sched_mostly_idle_freq
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "0" > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/boost 
echo "1" > /sys/module/msm_performance/parameters/touchboost 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/align_windows 
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active 

#Applying TCP/IP Parameters at System Boot
echo '256960' > /proc/sys/net/core/rmem_default
echo '256960' > /proc/sys/net/core/rmem_max 
echo '256960' >/proc/sys/net/core/wmem_default 
echo '256960' > /proc/sys/net/core/wmem_max
echo '0' > /proc/sys/net/ipv4/tcp_timestamps
echo '0' > /proc/sys/net/ipv4/tcp_sack
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling

#I/O 
echo 'cfq' > /sys/block/mmcblk0/queue/scheduler
echo 'cfq' > /sys/block/mmcblk1/queue/scheduler
echo '1024' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '1024' > /sys/block/mmcblk1/queue/read_ahead_kb
echo "75" > /sys/devices/system/cpu/cpufreq/performance/up_threshold
echo "40000" > /sys/devices/system/cpu/cpufreq/performance/sampling_rate
echo "5" > /sys/devices/system/cpu/cpufreq/performance/sampling_down_factor
echo "20" > /sys/devices/system/cpu/cpufreq/performance/down_threshold
echo "25" > /sys/devices/system/cpu/cpufreq/performance/freq_step/sys/class/kgsl/kgsl-3d0/devfreq/governor
echo "cfq" > /sys/block/sda/queue/scheduler
echo "1024" > /sys/block/sda/queue/read_ahead_kb
echo "0" > /sys/block/sda/queue/rotational
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/add_random
echo "1" > /sys/block/sda/queue/rq_affinity
echo "0" > /sys/block/sda/queue/nomerges
echo "1024" > /sys/block/sda/queue/nr_requests
echo "cfq" > /sys/block/sdb/queue/scheduler
echo "1024" > /sys/block/sdb/queue/read_ahead_kb
echo "0" > /sys/block/sdb/queue/rotational
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdb/queue/add_random
echo "1" > /sys/block/sdb/queue/rq_affinity
echo "0" > /sys/block/sdb/queue/nomerges
echo "1024" > /sys/block/sdb/queue/nr_requests
echo "cfq" > /sys/block/sdc/queue/scheduler
echo "1024" > /sys/block/sdc/queue/read_ahead_kb
echo "0" > /sys/block/sdc/queue/rotational
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdc/queue/add_random
echo "1" > /sys/block/sdc/queue/rq_affinity
echo "0" > /sys/block/sdc/queue/nomerges
echo "1024" > /sys/block/sdc/queue/nr_requests
echo "cfq" > /sys/block/sdd/queue/scheduler
echo "1024" > /sys/block/sdd/queue/read_ahead_kb
echo "0" > /sys/block/sdd/queue/rotational
echo "0" > /sys/block/sdd/queue/iostats
echo "0" > /sys/block/sdd/queue/add_random
echo "1" > /sys/block/sdd/queue/rq_affinity
echo "0" > /sys/block/sdd/queue/nomerges
echo "1024" > /sys/block/sdd/queue/nr_requests
echo "cfq" > /sys/block/sde/queue/scheduler
echo "1024" > /sys/block/sde/queue/read_ahead_kb
echo "0" > /sys/block/sde/queue/rotational
echo "0" > /sys/block/sde/queue/iostats
echo "0" > /sys/block/sde/queue/add_random
echo "1" > /sys/block/sde/queue/rq_affinity
echo "0" > /sys/block/sde/queue/nomerges
echo "1024" > /sys/block/sde/queue/nr_requests
echo "cfq" > /sys/block/sdf/queue/scheduler
echo "1024" > /sys/block/sdf/queue/read_ahead_kb
echo "0" > /sys/block/sdf/queue/rotational
echo "0" > /sys/block/sdf/queue/iostats
echo "0" > /sys/block/sdf/queue/add_random
echo "1" > /sys/block/sdf/queue/rq_affinity
echo "0" > /sys/block/sdf/queue/nomerges
echo "1024" > /sys/block/sdf/queue/nr_requests
echo "cfq" > /sys/block/mmcblk0/queue/scheduler
echo "1024" > /sys/block/mmcblk0/queue/read_ahead_kb
echo "0" > /sys/block/mmcblk0/queue/rotational
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0/queue/add_random
echo "1" > /sys/block/mmcblk0/queue/rq_affinity
echo "0" > /sys/block/mmcblk0/queue/nomerges
echo "1024" > /sys/block/mmcblk0/queue/nr_requests

echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 

#Speed Ram
echo '1024' > /sys/devices/virtual/block/zram0/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram7/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram8/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram9/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram10/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram11/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram12/queue/read_ahead_kb
echo '1024' > /sys/devices/virtual/block/ram13/queue/read_ahead_kb
echo '512' > /sys/block/ram0/queue/read_ahead_kb
echo '512' > /sys/block/ram1/queue/read_ahead_kb
echo '512' > /sys/block/ram2/queue/read_ahead_kb
echo '512' > /sys/block/ram3/queue/read_ahead_kb
echo '512' > /sys/block/ram4/queue/read_ahead_kb
echo '512' > /sys/block/ram5/queue/read_ahead_kb
echo '512' > /sys/block/ram6/queue/read_ahead_kb
echo '512' > /sys/block/ram7/queue/read_ahead_kb
echo '512' > /sys/block/ram8/queue/read_ahead_kb
echo '512' > /sys/block/ram9/queue/read_ahead_kb
echo '512' > /sys/block/ram10/queue/read_ahead_kb
echo '512' > /sys/block/ram11/queue/read_ahead_kb
echo '512' > /sys/block/ram12/queue/read_ahead_kb
echo '512' > /sys/block/ram13/queue/read_ahead_kb
echo '512' > /sys/block/ram14/queue/read_ahead_kb
echo '512' > /sys/block/ram15/queue/read_ahead_kb
echo '512' > /sys/block/vnswap0/queue/read_ahead_kb
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo '512' > /sys/devices/virtual/block/ram0/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram0/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram1/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram1/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram2/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram2/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram3/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram3/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram4/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram4/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram5/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram5/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram6/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram6/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram7/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram7/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram8/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram8/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram9/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram9/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram10/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram10/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram11/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram11/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram12/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram12/queue/max_sectors_kb
echo '512' > /sys/devices/virtual/block/ram13/queue/max_hw_sectors_kb
echo '512' > /sys/devices/virtual/block/ram13/queue/max_sectors_kb
echo "512" > /sys/devices/virtual/block/zram0/queue/max_hw_sectors_kb
echo "512" > /sys/devices/virtual/block/zram0/queue/max_sectors_kb
echo "512" > /sys/devices/virtual/bdi/1:0/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:1/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:2/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:3/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:4/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:5/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:6/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:7/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:8/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:9/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:10/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:11/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:12/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/1:13/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:0/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:8/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:16/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:24/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:32/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:40/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:48/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/7:56/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/179:0/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/179:32/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/179:64/read_ahead_kb
echo "512" > /sys/devices/virtual/bdi/253:0/read_ahead_kb

#Fstrim 
fstrim /data;
fstrim /system;
fstrim /cache;
fstrim /vendor;
fstrim /product;

# Cpu Input Boost
write /sys/module/cpu_input_boost/parameters/input_boost_duration "0"
write /sys/module/cpu_input_boost/parameters/dynamic_stune_boost_duration "0"
write /sys/module/cpu_input_boost/parameters/dynamic_stune_boost "80"

# Gpu Tweaks
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "1" > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo "1" > /sys/class/kgsl/kgsl-3d0/force_no_nap

# Dev Stune Boost
# Fast Sensivity in Game
write /dev/stune/background/schedtune.boost "20"
write /dev/stune/background/schedtune.prefer_idle "0"
write /dev/stune/background/schedtune.colocate "0"
write /dev/stune/background/schedtune.sched_boost_enabled "0"

write /dev/stune/foreground/schedtune.boost "20"
write /dev/stune/foreground/schedtune.prefer_idle "0"
write /dev/stune/foreground/schedtune.colocate "0"
write /dev/stune/foreground/schedtune.sched_boost_enabled "0"

write /dev/stune/rt/schedtune.boost "20"
write /dev/stune/rt/schedtune.prefer_idle "0"
write /dev/stune/rt/schedtune.colocate "0"
write /dev/stune/rt/schedtune.sched_boost_enabled "0"

write /dev/stune/top-app/schedtune.boost "20"
write /dev/stune/top-app/schedtune.prefer_idle "0"
write /dev/stune/top-app/schedtune.colocate "0"
write /dev/stune/top-app/schedtune.sched_boost_enabled "0"

write /dev/stune/schedtune.boost "20"
write /dev/stune/schedtune.prefer_idle "0"
write /dev/stune/schedtune.colocate "0"
write /dev/stune/schedtune.sched_boost_enabled "0"

sleep 80
done