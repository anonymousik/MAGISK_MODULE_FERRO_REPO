#!/system/bin/sh
# script Drop Cache nya banh 

# Will exec 60 sec after boot 
sleep 60

# Turu banh
echo "3" >/proc/sys/vm/drop_caches