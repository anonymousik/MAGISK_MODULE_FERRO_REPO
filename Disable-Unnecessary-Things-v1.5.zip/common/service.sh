#!/system/bin/sh
# Disable unnecessary things Execute script.

# Detect boot if complete or not from ktweak (tytydraco) , thanks ! 
while [[ "$(getprop sys.boot_completed)" -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 5
done

# Sleep 60s to avoid conflict with another boot script.
sleep 60

# Execute 
disableunc
