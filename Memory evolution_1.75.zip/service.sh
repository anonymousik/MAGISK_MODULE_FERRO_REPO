#!/system/bin/sh
MODDIR=${0%/*}
sh $MODDIR/script/set_io.sh
if [ ! -d "$MODDIR/../scene_swap_controller/" ]; then
sh $MODDIR/script/set_cpu_affinity.sh
sh $MODDIR/script/dis_mi_rtmm.sh
chmod +x $MODDIR/script/opt_writeback.sh
$MODDIR/script/opt_writeback.sh > /cache/writeback.log 2>&1 &
sh $MODDIR/script/opt_fstrim.sh
fi
