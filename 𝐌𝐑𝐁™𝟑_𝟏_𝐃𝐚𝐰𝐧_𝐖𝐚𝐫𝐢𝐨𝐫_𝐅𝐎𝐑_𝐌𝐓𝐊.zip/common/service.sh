#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}
ifconfig eth0 txqueuelen 100
# This script will be executed in late_start service mode

dbg "Sleeping until boot completes."
while [[ `getprop sys.boot_completed` -ne 1 ]]
do
       sleep 1
done

# Magisk Busybox Symlink for Apps
ln -s /sbin/.magisk/busybox/*

# Sleep
sleep 30

##𝐌𝐑𝐁™ - 𝐃𝐚𝐰𝐧 𝐖𝐚𝐫𝐢𝐨𝐫(CS&GS)
chmod 644 /sys/module/workqueue/parameters/power_efficient
echo 'Y' > /sys/module/workqueue/parameters/power_efficient
echo "100" > /sys/devices/system/cpu/cpufreq/performance/go_hispeed_load 
echo "1" > /sys/module/msm_performance/parameters/touchboost 
echo "0" > /sys/devices/system/cpu/cpufreq/performance/above_hispeed_delay 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/boost 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/max_freq_hysteresis 
echo "1" > /sys/devices/system/cpu/cpufreq/performance/align_windows 
echo "0" > /sys/module/adreno_idler/parameters/adreno_idler_active 
echo "8" > /sys/module/lazyplug/parameters/nr_possible_cores 
echo "0-2,4-7" > /dev/cpuset/foreground/cpus 
echo "4-7" > /dev/cpuset/foreground/boost/cpus 
echo "0-7" > /dev/cpuset/top-app/cpus 
echo "0-7" > /dev/cpuset/audio-app/cpus 
echo "0-7" > /dev/cpuset/background/cpus 
echo "0-7" > /dev/cpuset/camera-daemon/cpus 
echo "0-7" > /dev/cpuset/rt/cpus 
echo '0' > /sys/devices/system/cpu/isolated;
echo '0' > /sys/devices/system/cpu/offline;
echo '0' > /sys/devices/system/cpu/uevent;
echo '1' > /sys/devices/system/cpu/cpufreq/policy0/schedutil/iowait_boost_enable;
echo '1' > /sys/devices/system/cpu/cpufreq/policy4/schedutil/iowait_boost_enable;
echo "465" > /sys/kernel/gpu/gpu_min_clock;
echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
echo "0" > /sys/class/kgsl/kgsl-3d0/force_no_nap
echo "0" > /sys/class/kgsl/kgsl-3d0/force_bus_on
echo "0" > /sys/class/kgsl/kgsl-3d0/force_clk_on 
echo "0" > /sys/class/kgsl/kgsl-3d0/force_rail_on
echo "1" > /sys/class/kgsl/kgsl-3d0/bus_split

# 𝐌𝐑𝐁™ - 𝐃𝐚𝐰𝐧 𝐖𝐚𝐫𝐢𝐨𝐫
echo '0' > /proc/hps/enabled"
echo '1' > /proc/gpufreq/gpufreq_limited_thermal_ignore"
echo '0' > /sys/module/pvrsrvkm/parameter/gpu_dvfs_enable"
echo '1326000' > /proc/cpufreq/cpufreq_limited_max_freq_by_user” 
echo '823000' >/proc/gpufreq/gpufreq_opp_dump
echo 'always_on' > /sys/devices/platform/13040000.mali/power_policy  
echo '1000000' > /proc/gpufreq/gpufreq_opp_freq      
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governor 
echo "1350000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq 
echo "1350000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_min_freq 
echo "1700000" > /sys/devices/system/cpu/cpufreq/policy0/scaling_max_freq 
echo "2000000" > /sys/devices/system/cpu/cpufreq/policy6/scaling_max_freq 
echo "2000000" > /sys/devices/system/cpu/cpufreq/policy6/cpuinfo_max_freq 
echo "1350000" > /sys/devices/system/cpu/cpufreq/policy6/cpuinfo_min_freq 
echo "1700000" > /sys/devices/system/cpu/cpufreq/policy0/cpuinfo_max_freq 
echo "1350000" > /sys/devices/system/cpu/cpufreq/policy6/cpuinfo_max_freq 
echo "1000" > /sys/devices/system/cpu/cpufreq/schedutil/down_rate_limit_us
echo "1500" > /sys/devices/system/cpu/cpufreq/schedutil/up_rate_limit_us    
                                             
# LMK & Zram
stop perfd
echo '1' > /sys/block/zram0/reset
echo '2147483648' > /sys/block/zram0/disksize
echo '0' > /proc/sys/vm/page-cluster 
echo '4' > /sys/block/zram0/max_comp_streams 
echo 'lz4' > /sys/block/zram0/comp_algorithm
echo '100' > /proc/sys/vm/swappiness
echo '0' > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo '100' > /proc/sys/vm/overcommit_ratio
echo '200' > /proc/sys/vm/vfs_cache_pressure
echo '27200' > /proc/sys/vm/extra_free_kbytes
echo '256' > /proc/sys/kernel/random/read_wakeup_threshold
echo '256' > /proc/sys/kernel/random/write_wakeup_threshold
echo '0' > /sys/block/mmcblk0/queue/iostats
echo '1' > /sys/block/mmcblk0/queue/add_random
echo '0' > /sys/block/mmcblk1/queue/iostats
echo '1' > /sys/block/mmcblk1/queue/add_random
echo '4096' > /proc/sys/vm/min_free_kbytes
echo '0' > /proc/sys/vm/oom_kill_allocating_task
echo '90' > /proc/sys/vm/dirty_ratio
echo '70' > /proc/sys/vm/dirty_background_ratio
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo '256,10240,32000,34000,36360,43632' > /sys/module/lowmemorykiller/parameters/minfree

# Speed up
echo 'cfq' > /sys/block/sda/queue/scheduler
echo '1024' > /sys/block/sda/queue/read_ahead_kb
echo '0' > /sys/block/sda/queue/rotational
echo '0' > /sys/block/sda/queue/iostats
echo '0' > /sys/block/sda/queue/add_random
echo '1' > /sys/block/sda/queue/rq_affinity
echo '0' > /sys/block/sda/queue/nomerges
echo '512' > /sys/block/sda/queue/nr_requests
echo 'cfq' > /sys/block/sdb/queue/scheduler
echo '1024' > /sys/block/sdb/queue/read_ahead_kb
echo '0' > /sys/block/sdb/queue/rotational
echo '0' > /sys/block/sdb/queue/iostats
echo '0' > /sys/block/sdb/queue/add_random
echo '1' > /sys/block/sdb/queue/rq_affinity
echo '0' > /sys/block/sdb/queue/nomerges
echo '512' > /sys/block/sdb/queue/nr_requests
echo 'cfq' > /sys/block/sdc/queue/scheduler
echo '1024' > /sys/block/sdc/queue/read_ahead_kb
echo '0' > /sys/block/sdc/queue/rotational
echo '0' > /sys/block/sdc/queue/iostats
echo '0' > /sys/block/sdc/queue/add_random
echo '1' > /sys/block/sdc/queue/rq_affinity
echo '0' > /sys/block/sdc/queue/nomerges
echo '512' > /sys/block/sdc/queue/nr_requests
echo 'cfq' > /sys/block/sdd/queue/scheduler
echo '1024' > /sys/block/sdd/queue/read_ahead_kb
echo '0' > /sys/block/sdd/queue/rotational
echo '0' > /sys/block/sdd/queue/iostats
echo '0' > /sys/block/sdd/queue/add_random
echo '1' > /sys/block/sdd/queue/rq_affinity
echo '0' > /sys/block/sdd/queue/nomerges
echo '512' > /sys/block/sdd/queue/nr_requests
echo 'cfq' > /sys/block/sde/queue/scheduler
echo '1024' > /sys/block/sde/queue/read_ahead_kb
echo '0' > /sys/block/sde/queue/rotational
echo '0' > /sys/block/sde/queue/iostats
echo '0' > /sys/block/sde/queue/add_random
echo '1' > /sys/block/sde/queue/rq_affinity
echo '0' > /sys/block/sde/queue/nomerges
echo '512' > /sys/block/sde/queue/nr_requests
echo 'cfq' > /sys/block/sdf/queue/scheduler
echo '1024' > /sys/block/sdf/queue/read_ahead_kb
echo '0' > /sys/block/sdf/queue/rotational
echo '0' > /sys/block/sdf/queue/iostats
echo '0' > /sys/block/sdf/queue/add_random
echo '1' > /sys/block/sdf/queue/rq_affinity
echo '0' > /sys/block/sdf/queue/nomerges
echo '512' > /sys/block/sdf/queue/nr_requests

#I/O
echo '512' > /sys/block/mmcblk0/queue/read_ahead_kb
echo '256' > /sys/block/mmcblk0/queue/nr_requests
echo '512' > /sys/block/mmcblk1/queue/read_ahead_kb
echo '256' > /sys/block/mmcblk1/queue/nr_requests
echo 'cfq' > /sys/block/mmcblk0/queue/scheduler
echo 'cfq' > /sys/block/mmcblk1/queue/scheduler
echo '1024' > /sys/block/dm-0/queue/read_ahead_kb
echo '512' > /sys/block/dm-0/queue/nr_requests
echo '1024' > /sys/block/ram0/queue/read_ahead_kb
echo '1024' > /sys/block/ram1/queue/read_ahead_kb
echo '1024' > /sys/block/ram2/queue/read_ahead_kb
echo '1024' > /sys/block/ram3/queue/read_ahead_kb
echo '1024' > /sys/block/ram4/queue/read_ahead_kb
echo '1024' > /sys/block/ram5/queue/read_ahead_kb
echo '1024' > /sys/block/ram6/queue/read_ahead_kb
echo '1024' > /sys/block/ram7/queue/read_ahead_kb

#Misc
echo '0' > /sys/module/mmc_core/parameters/use_spi_crc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 

# Internet Booster
echo 'cubic' > /proc/sys/net/ipv4/tcp_congestion_control
echo '5' > /proc/sys/net/ipv4/tcp_fin_timeout
echo '30' > /proc/sys/net/ipv4/tcp_keepalive_intvl
echo '5' > /proc/sys/net/ipv4/tcp_keepalive_probes
echo '1' > /proc/sys/net/ipv4/tcp_tw_recycle
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse
echo '10000000' > /proc/sys/fs/file-max
echo '250000' > /sys/module/nf_conntrack/parameters/hashsize
echo 'cubic' > /proc/sys/net/ipv4/tcp_congestion_control
echo '1' > /proc/sys/net/ipv4/conf/all/rp_filter
echo '1' > /proc/sys/net/ipv4/conf/default/rp_filter
echo '1' > /proc/sys/net/ipv4/tcp_sack
echo '1' > /proc/sys/net/ipv4/tcp_window_scaling
echo '1' > /proc/sys/net/ipv4/tcp_no_metrics_save
echo '8738000' > /proc/sys/net/core/rmem_max
echo '6553600' > /proc/sys/net/core/wmem_max
echo '8192,873800,8738000' > /proc/sys/net/ipv4/tcp_rmem
echo '4096,655360,6553600' > /proc/sys/net/ipv4/tcp_wmem
echo '1' > /proc/sys/net/ipv4/tcp_tw_reuse
echo '360000' > /proc/sys/net/ipv4/tcp_max_tw_buckets
echo '30000' > /proc/sys/net/core/netdev_max_backlog
echo '16384'  > /proc/sys/net/ipv4/tcp_max_syn_backlog
echo '30000,65535' > /proc/sys/net/ipv4/ip_local_port_range
echo '1' > /proc/sys/net/ipv4/tcp_synack_retries
echo '400000' > /proc/sys/net/ipv4/tcp_max_orphans
echo '1000000' > /proc/sys/net/netfilter/nf_conntrack_max

# Google Service Config Reduce Drain
sleep '0.001'
su -c 'pm enable com.google.android.gms'
sleep '0.001'
su -c 'pm enable com.google.android.gsf'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceActiveReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gms/.update.SystemUpdateServiceSecretCodeReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdatePanoActivity'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateService'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceReceiver'
sleep '0.001'
su -c 'pm enable com.google.android.gsf/.update.SystemUpdateServiceSecretCodeReceiver'

#Fstrim 
fstrim /cache
fstrim /system
fstrim /data

iptables -t nat -I OUTPUT -p tcp --dport 53 -j DNAT --to-destination 8.8.8.8:53 2>/dev/null
iptables -t nat -I OUTPUT -p udp --dport 53 -j DNAT --to-destination 8.8.8.8:53 2>/dev/null

#MRB™℅√
chmod 0000 /system/vendor/etc/perfservapplist.txt
chmod 0000 /system/vendor/etc/perfservscntbl.txt    

chmod 777 /sys/class/power_supply/*/*
chmod 777 /sys/module/qpnp_smbcharger/*/*
chmod 777 /sys/module/dwc3_msm/*/*
chmod 777 /sys/module/phy_msm_usb/*/*
while true; do
echo '1' > /sys/kernel/fast_charge/force_fast_charge
echo '1' > /sys/class/power_supply/battery/system_temp_level
echo '1' > /sys/kernel/fast_charge/failsafe
echo '1' > /sys/class/power_supply/battery/allow_hvdcp3
echo '1' > /sys/class/power_supply/usb/pd_allowed
echo '1' > /sys/class/power_supply/battery/subsystem/usb/pd_allowed
echo '0' > /sys/class/power_supply/battery/input_current_limited
echo '1' > /sys/class/power_supply/battery/input_current_settled
echo '0' > /sys/class/qcom-battery/restricted_charging
echo '150' > /sys/class/power_supply/bms/temp_cool
echo '480' > /sys/class/power_supply/bms/temp_hot
echo '480' > /sys/class/power_supply/bms/temp_warm
echo '2650000' > /sys/class/power_supply/usb/current_max
echo '2650000' > /sys/class/power_supply/usb/hw_current_max
echo '2650000' > /sys/class/power_supply/usb/pd_current_max
echo '2650000' > /sys/class/power_supply/usb/ctm_current_max
echo '2650000' > /sys/class/power_supply/usb/sdp_current_max
echo '2650000' > /sys/class/power_supply/main/current_max
echo '2650000' > /sys/class/power_supply/main/constant_charge_current_max
echo '2650000' > /sys/class/power_supply/battery/current_max
echo '2650000' > /sys/class/power_supply/battery/constant_charge_current_max
echo '2650000' > /sys/class/qcom-battery/restricted_current
echo '2650000' > /sys/class/power_supply/pc_port/current_max
echo '2650000' > /sys/class/power_supply/constant_charge_current__max
sleep 1
done
