#!/system/bin/sh

MODDIR=${0%/*}

# Disable Core control / hotplug

for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done ;
exit 0