SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
"

# 64-bit detect inspired from @iamlooper , thanks !
installdetect(){
  if [[ $afakah64bit == yes ]]; then
mv -f $MODPATH/system/bin/dsblunc64 $MODPATH/system/bin/disableunc
else
mv -f $MODPATH/system/bin/dsblunc32 $MODPATH/system/bin/disableunc
fi;
}

# Set what you want to display when installing your module
print_modname(){
ui_print "        

█░█ █▀▀▄ ▀▀█▀▀ █▀▀▄ ░ ░ █▀▀█ █▀▀ █▀▀▄ █▀▀█ █▀▀█ █▀▀▄
█▀▄ █░░█ ░░█░░ █░░█ ▀ ▀ █▄▄▀ █▀▀ █▀▀▄ █░░█ █▄▄▀ █░░█
▀░▀ ▀░░▀ ░░▀░░ ▀▀▀░ ░ ░ ▀░▀▀ ▀▀▀ ▀▀▀░ ▀▀▀▀ ▀░▀▀ ▀░░▀
"
sleep 1
ui_print "                  Disable Unnecessary Things         "
ui_print "                         v1-stable              "
sleep 1
ui_print "- This module will disable some feature which is not needed phone to get more performance !"
ui_print "- Install Finish! "
ui_print "- Please Reboot!"
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  ui_print ""
  sleep 0,3
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  installdetect;
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0777 0755
}