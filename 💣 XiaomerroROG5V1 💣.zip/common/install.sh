,,,,,#!/system/bin/sh

# Set to true if you do *NOT* want Magisk to mount
# any files for you. Most modules would NOT want
# to set this flag to true
SKIPMOUNT=true

# Set to true if you need to load system.prop
PROPFILE=true

# Set to true if you need post-fs-data script
POSTFSDATA=true

# Set to true if you need late_start service script
LATESTARTSERVICE=true
##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/FKM
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE=" 
/common/system/app/fkm.apk
/common/system/lib/egl/egl.cfg
/common/System/lib/RogPhone-Extensions
"
##########################################################################################
#
sleep 2
  ui_print "  💣 XiaomerroROG5 💣  "
  sleep 3
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *       Ten moduł Bez modyfikacji Pliki gry *"
  ui_print " * *"
  ui_print " * *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  sleep 3
  ui_print " *************************************************************************"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"  
  ui_print " *   Bez bana Bez zmiany danych bez ZMIANY PLIKU GRY *"
  ui_print " * TO NIE PLIK KONFIGURACYJNY A NIE HACK                    *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *                                                             *"
  ui_print " *************************************************************************"
  sleep 3
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *         ✔   Poprawka opóźnienia żyroskopu ✔              *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  sleep 5
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *     ✔  Całkowite usunięcie desynchronizacji gier ✔          *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  sleep 5
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *           ✔  Szybkie ladowanie ✔                     *"
  ui_print " *        bez spadku wydajności w grach            *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print " 🍅Bez modyfikacji plików gry, więc problem z kontem No Ban "
  ui_print " ŻADNYCH CHEATÓW I ŻADNYCH Hacków🍅💯"
  sleep 5
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *       ✔ zwiększ wydajność w grach ✔         *"
  ui_print " *               🌶 Supermoc 🌶                    *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print " "
  ui_print "            Zakończono flashowanie modułu w 50%"
  ui_print " "
  sleep 3
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *  ✔Aktywny Ȧṡu̇ṡ ̇ṘȮĠ ̇Ṗḣȯṅė ̇5̇ 90 FPS🗝️ odblokuj ✔ *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print "waiting......"
  sleep 24
  ui_print " ************************************************************** "
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *   ✔Aktywuj swoją częstotliwość odświeżania 72 Hz 90 Hz 120 Hz.       "
  ui_print "  145 Hz 165 Hz 240 Hz 🗝️ odblokowane we wszystkich grach ✔ *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " *                                                     *"
  ui_print " ************************************************************** "
  ui_print "waiting......"
  sleep 40
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *      💣*Aktywny Ȧṡu̇ṡ ̇ṘȮĠ ̇Ṗḣȯṅė ̇5̇ Grafika*✔ *"
  ui_print ".            * jak Rog Phone 5                       *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  sleep 3
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *       💣*Aktywny Ȧṡu̇ṡ ̇ṘȮĠ ̇Ṗḣȯṅė ̇5̇ CPU/GPU*✔    *"
  ui_print " *                  Nowy procesor graficzny                    *"
  ui_print " *           Wartość Przeciążenie częstotliwości 🔥            *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  sleep 3
  ui_print " "
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *     💣*Aktywny Ȧṡu̇ṡ ̇ṘȮĠ ̇Ṗḣȯṅė ̇5̇ Wydajność*✔    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  ui_print " "
  ui_print " ************************************************************** "
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *   💣*Aktywny Ȧṡu̇ṡ ̇ṘȮĠ ̇Ṗḣȯṅė ̇5̇ Reakcja na dotyk*✔  *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " *                                                    *"
  ui_print " ************************************************************** "
  ui_print " "
  ui_print "  Niechaj Moc będzie z Tobą!👇  "
  
  ui_print "    By:  🇵🇱NieznanyNikomu Ferruś "
echo ""  
echo " installation completed 100%  just wait few sec "
echo " "
sleep 7
ui_print "• 𝗥𝗲𝗯𝗼𝗼𝘁 𝗡𝗼𝘄 !"
on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'common/functions.sh' -d $MODPATH
 >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
. $MODPATH/common/functions.sh
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
         set_perm_recursive $MODPATH 0 0 0755 0644
         set_perm $MODPATH/system/lib/egl/egl.cfg 0 0 0644
         set_perm_recursive $MODPATH/system/etc 0 0 0755 0644
         set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
         set_perm_recursive $MODPATH/common/system/bin 0 0 0755 0755
         set_perm_recursive $MODPATH/System/vendor/etc/thermal-engine-normal.conf 0 0 0755 0644
         set_perm_recursive $MODPATH/common/system/lib/RogPhone-Extensions 0 0 0755 0644
         
  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code

