PROPFILE=true

print_modname() {
ui_print
ui_print "=------ Heap Size Mod v2 ------="
ui_print
}

on_install() {
ui_print "- Extracting module files"
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
