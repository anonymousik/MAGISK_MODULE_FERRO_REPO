# !/sbin/sh

busybox mount /system

if [ ! -f /system/vendor/etc/thermal-engine.conf.parth ]; then
  cp /system/vendor/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

if [ ! -f /system/etc/thermal-engine.conf.parth ]; then
  cp /system/etc/thermal-engine.conf /system/vendor/etc/thermal-engine.conf.parth
fi

