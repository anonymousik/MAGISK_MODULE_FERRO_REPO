rm -rf /data/swapfile*
rm -f /data/swap_recreate
rm -f /data/swap_config.conf