#!/system/bin/sh
# Please don't hardcode /magisk/modname/... ; instead, please use $MODDIR/...
# This will make your scripts compatible even if Magisk change its mount point in the future
MODDIR=${0%/*}

# This script will be executed in post-fs-data mode
# More info in the main Magisk thread

# This script will be executed in post-fs-data mode
setenforce 0
stop logd
stop thermald
echo always_on > /sys/devices/platform/13040000.mali/power_policy;
echo alweys_on > /sys/devices/platform/13040000.mali/gpuinfo;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy4/scaling_setspeed;
echo alweys_support >/sys/devices/system/cpu/cpufreq/policy6/scaling_setspeed;
echo '1' > /sys/devices/system/cpu/sched/cpu_prefer;
echo boost > /sys/devices/system/cpu/sched/sched_boost;
echo '1' > /sys/devices/system/cpu/eas/enable;
echo 'boost' > /sys/devices/system/cpu/sched/sched_boost;
echo '3' > /proc/cpufreq/cpufreq_power_mode;
echo '1' > /proc/cpufreq/cpufreq_imax_enable;
echo '0' > /proc/cpufreq/cpufreq_imax_thermal_protect;
echo '1' > /sys/devices/system/cpu/perf/enable;
chmod '0644' > /sys/devices/system/cpu/perf/enable;
sleep 0.2
echo '35' > /dev/stune/foreground/schedtune.boost;
chmod '0444' /dev/stune/foreground/schedtune.boost;
echo '1' > /proc/cpufreq/cpufreq_cci_mode;
chmod '0444' /proc/cpufreq/cpufreq_cci_mode;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
done