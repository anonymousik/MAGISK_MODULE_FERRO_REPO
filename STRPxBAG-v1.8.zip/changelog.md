# v1.8 (100)
- Reworked Code 
- Adjusted Values
- Changed Sleep timer to 85
- Script Initialize Itself after 85 sec. / after Boot!
- Gyroscope Value is untouched.
- Added / Removed Props for better Stability
- Added New Notification Method, u will see it.
- Enjoy the Best & New Aim Assist & Bullet Register Version By Stratosphere!
-------------------------
# v1.7 (84)
- ADDED LOG File!
- U Can Find It Into ..
- LOG = /sdcard/.STRP/STRPxBAG.log
-------------------------
# v1.7 (83)
- Reworked Script
- Some Members of Group said that Games ex. CODM - PUBG and others... wont open anymore after flashing and reboot..
- Hope this Reworked Script and UPDATE will help u guys ⚡️
- Changed MinMagisk Support to 24300 - Magisk 24.3 Required!
-------------------------
# v1.7 (82)
- Reworked Script
-------------------------
# v1.7 New Mixture
- Name Changed! BAG is now a Part of STRP Family!
- Completly Reworked BAG Code!
- BAG Converted now into a bash script
- All what BAG Has will be AUTO set after Every Reboot!
- Just Update, reboot and Wait for the Toast!
- This Update is one of my BEST for FPS Games!
- U will Love it and be a PRO Player!
-------------------------
#  v1.6-HOTFIX
## (Versioncode - 79)
- Removed PUBG Extreme Graphic (Gets an own Module -Optional now)
- Removed PUBG Ultra Audio (Gets an own Module -Optional now)
- Added sound boost overall for device! NOT GAME SPECIFIC!
-------------------------
# v1.6
- Added PUBG ALL VERSIONS Ultra Audio Feature!
- Auto detect ur PUBG package and inflate ur audio .pak file!
- Reworked PUBG Extreme Graphic Script!
- Some adjustments in installer and tweaks made!
- Changed module Name. Just check urself..
-------------------------
# v1.5
### HOTFIX
- Toast Message don't appear when booting.
- Now Toast Pops Up so u can be sure BAG fully working!
-------------------------
# v1.4
- Updated BAG Module LOGO 
- FIXED PING AND DNS ISSUE 
- Fixed Dolby Atmos Conflict issue
- Removed (Disable FSync) due to Conflict with Stratosphere
- Added Enable Touchboost
- Added Kill Google Service's 
- Gain slightly Performance and reducing Battery Drain while Gaming.
- Some various code adjustments and fixes made
-------------------------
# v1.3
- Added PUBG UNIVERSAL XTREME GRAPHIC SCRIPT
- Type 'su -c PUBGEXTREME into Termux to execute script!
- Some Various Bug fixes!
- Combine with PUBG ULTRA AUDIO MODULE
- Avaiable on @AndroidRootModulesCommunity @Telegram
-------------------------
# v1.2
- Various Tweaks for Stability
- Added new Toast app from Stratosphere v2.0
- Fixed issues on some Devices to work Properly (Universal!)
- Added some new Props for AimAssist and BulletRegister!
-------------------------
# v1.0
- Redesigned Installer
- Thanks to @Legend_Gaming077
- Added new Props 
- Module is now Universal for All SoC's!
- Thx to @revWhiteShadow
- Added DNS Changer and Signal Boost
- For much better ping and Stability ingame 😎
- Added FSync OFF
- Better gaming Stability!
- Added Starting Notification
- After rebooting device!
- Added Games to Denylist/MagiskHide!
- incl. 
- NEW GAME APEX!
- Pubg [all versions]
- CODM
- Fortnite
- Free Fire 
- & More!

# Stay Fast 😎⚡️